
Memory Miner — GitHub Pages Ready Package
======================================

Your GitHub username: MuntaheenHamid
Your live game URL will be: https://MuntaheenHamid.github.io/memory-miner

Files included:
- index.html            : Playable prototype (single-file web game)
- manifest.json         : PWA manifest for adding to home screen
- icon-192.png, icon-512.png : App icons
- screenshot1.png, screenshot2.png, screenshot3.png : Store screenshots (placeholders)
- README.md             : This file

Steps to upload to GitHub Pages:
1. Go to https://github.com/signup and create a free account (done: MuntaheenHamid).
2. Create a new repository called `memory-miner` (check "Initialize with a README" optional).
3. Upload all files in this ZIP to the repository.
4. Go to Settings → Pages → Source → choose main branch → / (root), save.
5. Your game will be live at: https://MuntaheenHamid.github.io/memory-miner

Once live, I can then generate the Android APK (TWA) using this URL.
